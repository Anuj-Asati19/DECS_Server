#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/time.h>
#include <sys/select.h>

void error(char *msg) {
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[]) {
    char *fname;
    int sockfd = 0;

    if (argc != 7) {
        printf("Usage: <server-IP> <server-port> <file-name> <loop num> <sleep time> <time-out_seconds>\n");
        exit(1);
    }

    struct sockaddr_in serv_addr;
    struct hostent *server;

    int portno = atoi(argv[2]);
    server = gethostbyname(argv[1]);

    if (server == NULL) {
        printf("No such host available\n");
        exit(1);
    }

    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_port = htons(portno);
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);

    char fbuff[10000];
    fname = argv[3];
    int fd = open(fname, O_RDONLY);
    int fbr = read(fd, fbuff, 10000);

    int count = atoi(argv[4]);
    int ic = count;
    int sleep_time = atoi(argv[5]);
    int timeout = atoi(argv[6]);
    int time_sum = 0;
    int succ = 0;
    int timeout_count = 0;

    struct timeval start_time;
    gettimeofday(&start_time, NULL);

    while (count--) {
        sockfd = socket(AF_INET, SOCK_STREAM, 0);

        if (sockfd < 0) {
            printf("Error in creating a socket\n");
            exit(1);
        }

        if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
            printf("Couldn't connect!\n");
            exit(1);
        }

        struct timeval start_time;
        gettimeofday(&start_time, NULL);

        int fbw = write(sockfd, fbuff, fbr);

        if (fbw < 0) {
            printf("Error in writing\n");
        } else {
            fd_set read_fds;
            FD_ZERO(&read_fds);
            FD_SET(sockfd, &read_fds);

            struct timeval timeout;
            timeout.tv_sec = atoi(argv[6]);
            timeout.tv_usec = 0;

            int select_result = select(sockfd + 1, &read_fds, NULL, NULL, &timeout);

            if (select_result == 0) {
                printf("Timeout occurred while waiting for response.\n");
                timeout_count++;
            } else if (select_result < 0) {
                perror("Select error");
            } else {
                if (FD_ISSET(sockfd, &read_fds)) {
                    char res[1000];
                    int resbytes = read(sockfd, &res, 1000);

                    struct timeval end_time;
                    gettimeofday(&end_time, NULL);

                    int t_diff = (end_time.tv_sec * 1000 + end_time.tv_usec / 1000) - (start_time.tv_sec * 1000 + start_time.tv_usec / 1000);
                    time_sum += t_diff;
                    succ++;
                }
            }
        }
        sleep(sleep_time);
        close(sockfd);
    }

    struct timeval end_time;
    gettimeofday(&end_time, NULL);
    int t_diff = (end_time.tv_sec * 1000 + end_time.tv_usec / 1000) - (start_time.tv_sec * 1000 + start_time.tv_usec / 1000);

    float average = (float)time_sum / ic;
    printf("average:%f \nloop_iterations:%d \ntotal_time:%d \nthroughput:%f\n", average, ic, t_diff, (float)(succ * 1000) / t_diff);
    printf("Timeouts occurred: %d\n", timeout_count);

    close(fd);
}

