if [ $# -ne 3 ]; then
    echo "Usage <number of clients> <loop num> <sleep time>"
    exit
fi

gcc -o client multiclient.c
mkdir -p outputs
rm -f outputs/*
vmstat 10 > vmstat_output.txt &  # Monitor CPU utilization without subshell

sleep 5
for ((i=1; i<=$1; i++)); 
do
    ./client 127.0.0.1 3000 correct_code.c $2 $3 $i > outputs/op$i.txt &
done

# Capture active threads with 'ps' command and filter for the server process
ps -eLf | grep "server" > threads_output.txt

# Ensure the vmstat process is killed after the experiments
sleep 5  # Wait for your experiments to complete
pkill -f "vmstat 10"  # Kill the vmstat process

cat outputs/*.txt | awk '
    BEGIN{
        FS=":";
        sum=0;
        total=0;
        thru=0;
    }
    
    {
        if($1 ~ /throughput/ ){
            thru=thru+$2;
        }
        if($1 ~ /total_time/ ){
            ti = $2;
        }
        if($1 ~ /average/ ){
            avg = $2;
        }
        sum=sum+(ti*avg)
        total=total+ti;
    }

    END{
        printf("Average time taken = %f ms. Throughput = %f\n", sum/total, thru)
    }
'

