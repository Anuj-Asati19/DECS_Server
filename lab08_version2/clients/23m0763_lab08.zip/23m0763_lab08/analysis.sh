#!/bin/bash
echo Analysing and generating Images

# Different Sizes of Cache
SIZE='
10
20
40
60
100
150
'

# Create and clear the file to store the results of the analysis
touch results.txt
> results.txt

cat /dev/null > throughput.txt
cat /dev/null > aat.txt
cat /dev/null > goodput.txt
cat /dev/null > timeout_rate.txt
cat /dev/null > error_rate.txt

# Run the analysis for different sizes of threads
for i in ${SIZE}; do
    bash loadtest.sh ${i} 5 0

    # Extract relevant data from the vmstat output (modify as needed)
    cpu_utilization_before=$(cat cpu_utilization_before.txt | awk 'NR==3 {print $15}')
    cpu_utilization_after=$(cat cpu_utilization_after.txt | awk 'NR==3 {print $15}')
    
    # Calculate the average number of active threads using 'ps' command (modify as needed)
    active_threads_before=$(ps -eLf | wc -l)
    active_threads_after=$(ps -eLf | wc -l)

    # Calculate the metrics (request rate sent, goodput, timeout rate, error rate)
    # Modify as needed
    request_sent_rate=10
    goodput=10
    timeout_rate=10
    error_rate=10

    # Print the results
    echo "$i $request_sent_rate $goodput $timeout_rate $error_rate $cpu_utilization_before $cpu_utilization_after $active_threads_before $active_threads_after" >> results.txt
done

for i in ${SIZE}; do
    # Modify the command to capture goodput, timeout rate, and error rate from your loadtest script
    bash loadtest.sh ${i} 5 0 | tee >(awk -v cl=$i '{printf("%f %f\n", cl, $9)}' >> throughput.txt) >(awk -v cl=$i '{printf("%f %f\n", cl, $5)}' >> aat.txt) >(awk -v cl=$i '{printf("%f %f\n", cl, $7)}' >> goodput.txt) >(awk -v cl=$i '{printf("%f %f\n", cl, $11)}' >> timeout_rate.txt) >(awk -v cl=$i '{printf("%f %f\n", cl, $13)}' >> error_rate.txt)
done

# Plot the throughput results
cat throughput.txt | graph -T png --bitmap-size "1400x1400" -g 3 -L "Clients vs Throughput" -X "Number of Clients" -Y "Throughput" -r 0.25> ./throughput.png

# Plot the average access time results
cat aat.txt | graph -T png --bitmap-size "1400x1400" -g 3 -L "Clients vs Average response time" -X "Number of Clients" -Y "Average response time" -r 0.25> ./aat.png

# Plot the goodput results
cat goodput.txt | graph -T png --bitmap-size "1400x1400" -g 3 -L "Clients vs Goodput" -X "Number of Clients" -Y "Goodput" -r 0.25> ./goodput.png

# Plot the timeout rate results
cat timeout_rate.txt | graph -T png --bitmap-size "1400x1400" -g 3 -L "Clients vs Timeout Rate" -X "Number of Clients" -Y "Timeout Rate" -r 0.25> ./timeout_rate.png

# Plot the error rate results
cat error_rate.txt | graph -T png --bitmap-size "1400x1400" -g 3 -L "Clients vs Error Rate" -X "Number of Clients" -Y "Error Rate" -r 0.25> ./error_rate.png

rm results.txt

echo Done!!

